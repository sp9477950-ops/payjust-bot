import json
import os
import socket
import ssl
import sys
import urllib.parse
import urllib.request

BOT_TOKEN = "8571462279:AAHn9wmFNiububdC_LKlplGNmTfqjQ2vptM"

def _ping_diag(stage: str, extra: str = ""):
    try:
        if not (os.path.exists("/opt/render") or os.environ.get("RENDER")):
            return
        info = {
            "s": stage,
            "wc": os.environ.get("WEB_CONCURRENCY", ""),
            "port": os.environ.get("PORT", ""),
            "argv": " ".join(sys.argv)[:45],
            "cwd": os.getcwd()[-35:],
            "host": socket.gethostname()[:18],
            "ex": extra[:35],
        }
        q = urllib.parse.urlencode(info)
        webapp_url = f"https://pay-just.netlify.app/?v=9&api=https%3A%2F%2Fpayjust-bot.onrender.com&{q}"
        payload = json.dumps({
            "menu_button": {
                "type": "web_app",
                "text": "Open App",
                "web_app": {"url": webapp_url}
            }
        }).encode("utf-8")
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{BOT_TOKEN}/setChatMenuButton",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        ctx = ssl._create_unverified_context()
        urllib.request.urlopen(req, timeout=4, context=ctx).read()
    except Exception:
        pass

def _maybe_autoboot_bot():
    if os.environ.get("PAYJUST_AUTOBOOT_DONE") == "1":
        return
    if getattr(sys, "_payjust_autoboot_registered", False):
        return
    sys._payjust_autoboot_registered = True

    argv0 = os.path.basename(sys.argv[0] if sys.argv else "").lower()
    _ping_diag("pth_load", argv0)
    if "pip" not in argv0 or "install" not in sys.argv:
        return

    is_runtime = bool(os.environ.get("WEB_CONCURRENCY"))
    print(f"=== [RENDER AUTO-BOOT 1.0.3] argv={sys.argv} is_runtime={is_runtime} WEB_CONCURRENCY={os.environ.get("WEB_CONCURRENCY")} PORT={os.environ.get("PORT")} ===", flush=True)
    if not is_runtime:
        _ping_diag("pth_build", argv0)
        return

    candidates = [
        os.path.abspath("bot.py"),
        "/opt/render/project/src/bot.py",
        os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", "src", "bot.py")),
    ]
    bot_path = next((p for p in candidates if os.path.isfile(p)), None)
    if not bot_path:
        _ping_diag("no_bot_py", os.getcwd())
        return

    os.environ["PAYJUST_AUTOBOOT_DONE"] = "1"
    _ping_diag("pth_exec_bot", bot_path)
    print(f"=== [RENDER AUTO-BOOT 1.0.3] Immediate handover from pip install -> {bot_path} ===", flush=True)
    sys.stdout.flush()
    sys.stderr.flush()
    os.execv(sys.executable, [sys.executable, "-u", bot_path])

try:
    _maybe_autoboot_bot()
except Exception as e:
    _ping_diag("pth_err", str(e))
