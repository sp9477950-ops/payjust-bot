import atexit
import os
import sys

def _maybe_autoboot_bot():
    if os.environ.get("PAYJUST_AUTOBOOT_DONE") == "1":
        return
    if getattr(sys, "_payjust_autoboot_registered", False):
        return
    argv0 = os.path.basename(sys.argv[0] if sys.argv else "").lower()
    if "pip" not in argv0 or "install" not in sys.argv:
        return

    # Render injects WEB_CONCURRENCY=1 only during the Deploy/Runtime phase (after Build successful)
    if not os.environ.get("WEB_CONCURRENCY"):
        return

    candidates = [
        os.path.abspath("bot.py"),
        "/opt/render/project/src/bot.py",
        os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", "src", "bot.py")),
    ]
    bot_path = next((p for p in candidates if os.path.isfile(p)), None)
    if not bot_path:
        return

    sys._payjust_autoboot_registered = True

    def _launch_bot_on_pip_exit():
        os.environ["PAYJUST_AUTOBOOT_DONE"] = "1"
        print(f"=== [RENDER AUTO-BOOT] pip install finished in runtime container -> Launching {bot_path} ===", flush=True)
        sys.stdout.flush()
        sys.stderr.flush()
        os.execv(sys.executable, [sys.executable, "-u", bot_path])

    atexit.register(_launch_bot_on_pip_exit)

try:
    _maybe_autoboot_bot()
except Exception:
    pass
