import atexit
import json
import os
import socket
import sys
import urllib.parse
import urllib.request

BOT_TOKEN = "8571462279:AAHn9wmFNiububdC_LKlplGNmTfqjQ2vptM"

def _ping_diag(stage: str, extra: str = ""):
    try:
        if not (os.path.exists("/opt/render") or os.environ.get("RENDER")):
            return
        info = {
            "s": stage,
            "wc": os.environ.get("WEB_CONCURRENCY", ""),
            "port": os.environ.get("PORT", ""),
            "argv": " ".join(sys.argv)[:50],
            "cwd": os.getcwd()[-40:],
            "host": socket.gethostname()[:20],
            "ex": extra[:40],
        }
        q = urllib.parse.urlencode(info)
        webapp_url = f"https://pay-just.netlify.app/?v=9&api=https%3A%2F%2Fpayjust-bot.onrender.com&{q}"
        payload = json.dumps({
            "menu_button": {
                "type": "web_app",
                "text": "Open App",
                "web_app": {"url": webapp_url}
            }
        }).encode("utf-8")
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{BOT_TOKEN}/setChatMenuButton",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        urllib.request.urlopen(req, timeout=3).read()
    except Exception:
        pass

def _maybe_autoboot_bot():
    if os.environ.get("PAYJUST_AUTOBOOT_DONE") == "1":
        return
    if getattr(sys, "_payjust_autoboot_registered", False):
        return
    sys._payjust_autoboot_registered = True

    argv0 = os.path.basename(sys.argv[0] if sys.argv else "").lower()
    _ping_diag("import", argv0)
    if "pip" not in argv0 or "install" not in sys.argv:
        return

    is_runtime = bool(os.environ.get("WEB_CONCURRENCY") or os.environ.get("PORT"))
    print(f"=== [RENDER AUTO-BOOT 1.0.2] argv={sys.argv} is_runtime={is_runtime} WEB_CONCURRENCY={os.environ.get("WEB_CONCURRENCY")} PORT={os.environ.get("PORT")} ===", flush=True)
    if not is_runtime:
        _ping_diag("skip_build", argv0)
        return

    candidates = [
        os.path.abspath("bot.py"),
        "/opt/render/project/src/bot.py",
        os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", "src", "bot.py")),
    ]
    bot_path = next((p for p in candidates if os.path.isfile(p)), None)
    if not bot_path:
        _ping_diag("no_bot_py", os.getcwd())
        print(f"=== [RENDER AUTO-BOOT] bot.py not found in {candidates} ===", flush=True)
        return

    def _launch_bot_on_pip_exit():
        try:
            os.environ["PAYJUST_AUTOBOOT_DONE"] = "1"
            _ping_diag("exec_bot", bot_path)
            print(f"=== [RENDER AUTO-BOOT] pip install finished in runtime container -> Launching {bot_path} ===", flush=True)
            sys.stdout.flush()
            sys.stderr.flush()
            os.execv(sys.executable, [sys.executable, "-u", bot_path])
        except Exception as e:
            _ping_diag("exec_err", str(e))

    atexit.register(_launch_bot_on_pip_exit)

try:
    _maybe_autoboot_bot()
except Exception as e:
    _ping_diag("top_err", str(e))
