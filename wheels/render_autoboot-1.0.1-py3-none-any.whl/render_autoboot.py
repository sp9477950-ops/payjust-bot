import atexit
import os
import sys

def _maybe_autoboot_bot():
    if os.environ.get("PAYJUST_AUTOBOOT_DONE") == "1":
        return
    argv0 = os.path.basename(sys.argv[0] if sys.argv else "").lower()
    if "pip" not in argv0 or "install" not in sys.argv:
        return
    is_runtime = bool(os.environ.get("WEB_CONCURRENCY") or os.environ.get("PORT"))
    print(f"=== [RENDER AUTO-BOOT CHECK] argv={sys.argv} is_runtime={is_runtime} WEB_CONCURRENCY={os.environ.get("WEB_CONCURRENCY")} PORT={os.environ.get("PORT")} ===", flush=True)
    if not is_runtime:
        return

    candidates = [
        os.path.abspath("bot.py"),
        "/opt/render/project/src/bot.py",
        os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", "src", "bot.py")),
    ]
    bot_path = next((p for p in candidates if os.path.isfile(p)), None)
    if not bot_path:
        print(f"=== [RENDER AUTO-BOOT] bot.py not found in {candidates} ===", flush=True)
        return

    if getattr(sys, "_payjust_autoboot_registered", False):
        return
    sys._payjust_autoboot_registered = True

    def _launch_bot_on_pip_exit():
        os.environ["PAYJUST_AUTOBOOT_DONE"] = "1"
        print(f"=== [RENDER AUTO-BOOT] pip install finished in runtime container -> Launching {bot_path} ===", flush=True)
        sys.stdout.flush()
        sys.stderr.flush()
        os.execv(sys.executable, [sys.executable, "-u", bot_path])

    atexit.register(_launch_bot_on_pip_exit)

try:
    _maybe_autoboot_bot()
except Exception as e:
    print(f"=== [RENDER AUTO-BOOT ERROR] {e} ===", flush=True)
